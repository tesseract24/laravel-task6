<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
            

<div class="container" style="text-align: center;">
        <form method="POST" action=" <?php echo e(route('productsstore')); ?> ">
            <?php echo csrf_field(); ?>
            <br>
            <h1>INPUT PRODUCT</h1>

            <br>
            <label><b>title</b></label>
            
            <input class="form-control" type="text" name="title" placeholder="enter title">
            
            <br>
            <label><b>description</b></label>
            
            <textarea class="form-control" name="description" placeholder="enter description"></textarea>
            
            <br>
            <button class="btn btn-primary " type="submit" style="margin-left: 45%" >submit</button>
        </form>
        
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luffex/Desktop/laravel-task6/backend-task6/resources/views/inputproduct.blade.php ENDPATH**/ ?>