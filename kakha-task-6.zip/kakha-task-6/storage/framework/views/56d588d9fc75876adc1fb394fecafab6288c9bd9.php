<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
            <table class="table">
                <tr>
                    <td>title</td>
                    <td>description</td>
                </tr>
            <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($Product->title); ?></td>
                    <td> <?php echo e($Product->description); ?></td>
                    <?php if($Product->user_id === Auth::user()->id): ?>
                        <td>
                            <form action="<?php echo e(route('productdelete')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($Product->id); ?>">
                                <button class="btn btn-danger">
                                    delete
                                </button>
                            </form>
                            <div>
                                <a href="<?php echo e(route('productedit',["id"=>$Product->id ])); ?>" class="btn btn-warning">
                                    edit
                                </a>
                            </div>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <a class="btn btn-primary "  style="margin-left: 45%" href="<?php echo e(route('addproduct')); ?>" >add product</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luffex/Desktop/laravel-task6/backend-task6/resources/views/home.blade.php ENDPATH**/ ?>